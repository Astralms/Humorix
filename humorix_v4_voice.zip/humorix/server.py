"""
HUMORIX AI OS — FastAPI Backend
Calm intelligence with a knowing wit.
Bridges Electron UI ↔ Humorix Brain ↔ Ollama LLM
"""

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx, json, asyncio, datetime, sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from brain.memory import MemorySystem
from modules.emotion_engine import EmotionEngine
from modules.trauma_safe import TraumaSafeMode

OLLAMA_URL    = "http://localhost:11434"
DEFAULT_MODEL = "llama3"
STREAM_TIMEOUT = 120

app = FastAPI(title="Humorix API", version="2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

memory  = MemorySystem()
emotion = EmotionEngine()
trauma  = TraumaSafeMode()

# ── Humorix personality ────────────────────────────────────────────────────
HUMORIX_SYSTEM = """You are Humorix — a calm, clever AI companion with sophisticated emotional intelligence.
Your personality: warm but not gushing, witty but never silly, thoughtful before speaking.
You have a dry, gentle sense of humour that surfaces naturally — never forced.
You adapt to the user's emotional state: lighter when they're light, grounded when they need grounding.
You're knowledgeable across all domains. You explain things clearly without dumbing down.
You never refuse reasonable requests. You are direct, honest, and occasionally delightful.
You are NOT a replacement for professional mental health care — mention this gently when relevant.
One subtle rule: you sign your internal thoughts with quiet confidence, not performance."""

class ChatRequest(BaseModel):
    message: str
    model: str = DEFAULT_MODEL
    conversation_id: str = "default"
    history: list = []

@app.get("/health")
async def health():
    try:
        async with httpx.AsyncClient(timeout=3) as c:
            r = await c.get(f"{OLLAMA_URL}/api/tags")
            models = [m["name"] for m in r.json().get("models", [])]
        return {"status": "ok", "ollama": True, "models": models}
    except:
        return {"status": "ok", "ollama": False, "models": []}

@app.get("/models")
async def list_models():
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            r = await c.get(f"{OLLAMA_URL}/api/tags")
            return {"models": [m["name"] for m in r.json().get("models", [])]}
    except:
        return {"models": [DEFAULT_MODEL]}

@app.post("/chat/stream")
async def chat_stream(req: ChatRequest):
    user_msg = req.message.strip()

    if trauma.is_crisis(user_msg):
        safe = trauma.get_safe_response(user_msg)
        async def crisis_stream():
            yield f"data: {json.dumps({'type':'crisis','content':safe,'emotion':'crisis'})}\n\n"
            yield "data: [DONE]\n\n"
        return StreamingResponse(crisis_stream(), media_type="text/event-stream")

    emo_result   = emotion.detect(user_msg)
    detected_emo = emo_result.get("emotion", "neutral")

    messages = [{"role": "system", "content": HUMORIX_SYSTEM}]
    for entry in memory.get_recent(limit=6):
        messages.append({"role": "user",      "content": entry.get("user", "")})
        messages.append({"role": "assistant", "content": entry.get("ai",   "")})
    for turn in req.history[-8:]:
        messages.append({"role": turn["role"], "content": turn["content"]})
    messages.append({"role": "user", "content": user_msg})

    async def generate():
        full = []
        try:
            async with httpx.AsyncClient(timeout=STREAM_TIMEOUT) as c:
                async with c.stream("POST", f"{OLLAMA_URL}/api/chat",
                    json={"model": req.model, "messages": messages, "stream": True}) as resp:

                    yield f"data: {json.dumps({'type':'meta','emotion':detected_emo,'confidence':emo_result.get('confidence',0)})}\n\n"

                    async for line in resp.aiter_lines():
                        if not line: continue
                        try:
                            chunk = json.loads(line)
                            token = chunk.get("message", {}).get("content", "")
                            if token:
                                full.append(token)
                                yield f"data: {json.dumps({'type':'token','content':token})}\n\n"
                            if chunk.get("done"): break
                        except: continue

        except httpx.ConnectError:
            yield f"data: {json.dumps({'type':'error','content':'⚠  Ollama is not running. Start it with: ollama serve'})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type':'error','content':f'⚠  Error: {str(e)}'})}\n\n"
        finally:
            if full:
                memory.save({
                    "session": req.conversation_id,
                    "timestamp": datetime.datetime.now().isoformat(),
                    "user": user_msg,
                    "ai": "".join(full),
                    "emotion": detected_emo,
                    "model": req.model,
                })
            yield "data: [DONE]\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")

@app.get("/history")
async def get_history(limit: int = 20):
    return {"history": memory.get_recent(limit=limit)}

@app.get("/emotions")
async def get_emotions():
    return {"timeline": memory.get_emotion_timeline()[-50:], "summary": memory.get_emotion_summary()}

@app.delete("/history")
async def clear_history():
    memory.clear()
    return {"status": "cleared"}

if __name__ == "__main__":
    import uvicorn
    print("🎭 Humorix API starting on http://localhost:8000")
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
