"""
HUMORIX AI OS — Brain (Central Orchestrator)
Connects all modules and routes inputs to the right handlers.
"""

import json
import datetime
from brain.memory import MemorySystem
from modules.emotion_engine import EmotionEngine
from modules.counselling_engine import CounsellingEngine
from modules.trauma_safe import TraumaSafeMode
from modules.voice_handler import VoiceHandler
from modules.face_handler import FaceHandler
from modules.guardian import Guardian


class HumorixBrain:
    def __init__(self):
        print("[Brain] Initializing Humorix AI OS...")
        self.memory = MemorySystem()
        self.emotion_engine = EmotionEngine()
        self.counselling_engine = CounsellingEngine()
        self.trauma_safe = TraumaSafeMode()
        self.voice_handler = VoiceHandler()
        self.face_handler = FaceHandler()
        self.session_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.context = {}
        print("[Brain] All modules loaded. Humorix is ready.")

    def process_input(self, user_input: str, input_type: str = "text") -> dict:
        """
        Main entry point. Routes input through all relevant modules.
        Returns a structured response dict.
        """
        # Step 1: Trauma / crisis check (highest priority)
        if self.trauma_safe.is_crisis(user_input):
            response = self.trauma_safe.get_safe_response(user_input)
            self._log_interaction(user_input, response, emotion="crisis")
            return {"type": "trauma_safe", "response": response, "emotion": "crisis"}

        # Step 2: Detect emotion
        emotion_result = self.emotion_engine.detect(user_input)
        detected_emotion = emotion_result.get("emotion", "neutral")
        confidence = emotion_result.get("confidence", 0.0)

        # Step 3: Load memory context
        user_history = self.memory.get_recent(limit=5)

        # Step 4: Route to counselling engine with full context
        counsel_response = self.counselling_engine.respond(
            user_input=user_input,
            emotion=detected_emotion,
            history=user_history,
            context=self.context
        )

        # Step 5: Store to memory
        self._log_interaction(user_input, counsel_response, emotion=detected_emotion)

        return {
            "type": "normal",
            "response": counsel_response,
            "emotion": detected_emotion,
            "confidence": confidence,
        }

    def _log_interaction(self, user_input, response, emotion="neutral"):
        self.memory.save({
            "session": self.session_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "user": user_input,
            "ai": response,
            "emotion": emotion
        })

    def start_voice_input(self):
        return self.voice_handler.listen()

    def start_face_detection(self):
        return self.face_handler.detect()

    def get_emotion_history(self):
        return self.memory.get_emotion_timeline()

    def shutdown(self):
        print("[Brain] Shutting down Humorix gracefully...")
        self.memory.flush()
