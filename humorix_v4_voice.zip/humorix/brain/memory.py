"""
HUMORIX — Memory System
Stores conversations, emotion patterns, and user history.
Uses local JSON storage (can be swapped for SQLite/cloud later).
"""

import json
import os
import datetime
from pathlib import Path


MEMORY_DIR = Path("data/memory")
MEMORY_FILE = MEMORY_DIR / "interactions.json"
EMOTION_FILE = MEMORY_DIR / "emotion_timeline.json"


class MemorySystem:
    def __init__(self):
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        self._interactions = self._load(MEMORY_FILE)
        self._emotion_timeline = self._load(EMOTION_FILE)

    def _load(self, path: Path) -> list:
        if path.exists():
            try:
                with open(path, "r") as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    def _save(self, path: Path, data: list):
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def save(self, entry: dict):
        """Save an interaction entry."""
        self._interactions.append(entry)
        # Track emotion separately
        if "emotion" in entry:
            self._emotion_timeline.append({
                "timestamp": entry.get("timestamp", datetime.datetime.now().isoformat()),
                "emotion": entry["emotion"],
                "session": entry.get("session", "unknown")
            })
        self._auto_flush()

    def get_recent(self, limit: int = 5) -> list:
        """Return the last N interactions."""
        return self._interactions[-limit:]

    def get_emotion_timeline(self) -> list:
        """Return full emotion history."""
        return self._emotion_timeline

    def get_emotion_summary(self) -> dict:
        """Count emotion frequencies."""
        summary = {}
        for entry in self._emotion_timeline:
            e = entry.get("emotion", "unknown")
            summary[e] = summary.get(e, 0) + 1
        return summary

    def search(self, keyword: str) -> list:
        """Search past interactions by keyword."""
        results = []
        for entry in self._interactions:
            if keyword.lower() in entry.get("user", "").lower():
                results.append(entry)
        return results

    def flush(self):
        """Force save everything to disk."""
        self._save(MEMORY_FILE, self._interactions)
        self._save(EMOTION_FILE, self._emotion_timeline)

    def _auto_flush(self):
        """Auto-save every 10 entries."""
        if len(self._interactions) % 10 == 0:
            self.flush()

    def clear(self):
        """Wipe memory (use carefully)."""
        self._interactions = []
        self._emotion_timeline = []
        self.flush()
