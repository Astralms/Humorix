# Humorix AI OS
### Calm intelligence with a knowing wit

---

## What changed from Nurofix

| Before | After |
|---|---|
| Nurofix | **Humorix** |
| "Ultimate AI OS" framing | Calm, clever companion |
| Tkinter UI | Electron desktop app |
| Keyword-only responses | Ollama LLM (llama3/mistral/phi3) |
| Single sidebar | Sidebar with Chats · Memory · Settings tabs |
| Basic emotion badge | Emotion orb with confidence bar |
| Generic system prompt | Humorix personality (calm, witty, grounded) |

---

## Setup (3 steps)

**1 — Install Ollama + model**
```bash
# https://ollama.com/download
ollama pull mistral      # recommended for mid-range PC (~5GB RAM)
ollama serve
```

**2 — Start Python backend**
```bash
pip install fastapi uvicorn httpx pydantic
python server.py
```

**3 — Launch desktop app**
```bash
npm install     # needs Node.js from nodejs.org
npm start
```

---

## Project layout

```
humorix/
├── server.py              ← FastAPI backend (Humorix personality)
├── package.json           ← Electron config
├── requirements.txt
├── brain/
│   ├── brain.py           ← Central orchestrator
│   └── memory.py          ← Conversation + emotion storage
├── modules/
│   ├── emotion_engine.py
│   ├── counselling_engine.py
│   ├── trauma_safe.py
│   ├── voice_handler.py
│   ├── face_handler.py
│   └── guardian.py
├── electron/
│   ├── main.js
│   ├── preload.js
│   └── index.html         ← The UI (dark blue-green, Humorix branded)
└── data/memory/           ← Auto-created
```

---

## Model guide (mid-range PC)

| Model   | RAM   | Best for              |
|---------|-------|-----------------------|
| phi3    | ~3GB  | Fast answers          |
| mistral | ~5GB  | Balanced — recommended |
| llama3  | ~8GB  | Highest quality       |

---

## Build a distributable

```bash
npm run build:win   # → dist/Humorix AI OS Setup.exe
npm run build:mac   # → dist/Humorix AI OS.dmg
```
