const { app, BrowserWindow, ipcMain, shell } = require('electron')
const path = require('path')
const { spawn } = require('child_process')

let mainWindow, pythonProcess

function startBackend() {
  const python = process.platform === 'win32' ? 'python' : 'python3'
  pythonProcess = spawn(python, ['-m', 'uvicorn', 'server:app',
    '--host', '127.0.0.1', '--port', '8000'], {
    cwd: path.join(__dirname, '..'),
    stdio: ['ignore', 'pipe', 'pipe']
  })
  pythonProcess.stdout.on('data', d => console.log('[Humorix API]', d.toString().trim()))
  pythonProcess.stderr.on('data', d => console.error('[Humorix ERR]', d.toString().trim()))
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200, height: 820,
    minWidth: 820, minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#060D1A',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
  })
  mainWindow.loadFile(path.join(__dirname, 'index.html'))
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url)
    return { action: 'deny' }
  })
}

ipcMain.on('win-min',   () => mainWindow?.minimize())
ipcMain.on('win-max',   () => mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow?.maximize())
ipcMain.on('win-close', () => mainWindow?.close())

app.whenReady().then(() => {
  startBackend()
  setTimeout(createWindow, 1500)
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow() })
})
app.on('window-all-closed', () => { pythonProcess?.kill(); if (process.platform !== 'darwin') app.quit() })
app.on('before-quit', () => pythonProcess?.kill())
