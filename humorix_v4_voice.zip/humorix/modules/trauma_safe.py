"""
HUMORIX — Trauma Safe Mode
Detects crisis/sensitive inputs and responds with safe, supportive messages.
IMPORTANT: This is NOT a replacement for professional mental health care.
"""

import re

# Crisis signal phrases — expand carefully
CRISIS_SIGNALS = [
    r"\bsuicid\b", r"\bkill myself\b", r"\bend my life\b", r"\bwant to die\b",
    r"\bself.harm\b", r"\bcut myself\b", r"\bhurt myself\b", r"\bno reason to live\b",
    r"\bcan't go on\b", r"\bgive up on life\b", r"\bnot worth living\b",
    r"\boverdose\b", r"\bjump off\b", r"\bhang myself\b",
]

SAFE_RESPONSES = [
    (
        "I hear you, and I'm really glad you reached out. What you're feeling sounds incredibly heavy. "
        "Please know you don't have to face this alone.\n\n"
        "🆘 If you're in immediate danger, please contact a crisis helpline:\n"
        "  • India: iCall — 9152987821\n"
        "  • International: findahelpline.com\n\n"
        "I'm here with you. Can you tell me a little more about what's going on?"
    ),
    (
        "Thank you for trusting me with this. Your life matters deeply.\n\n"
        "Please reach out to someone who can help right now:\n"
        "  • India: Vandrevala Foundation — 1860-2662-345 (24/7)\n"
        "  • International: findahelpline.com\n\n"
        "I'm not going anywhere. I'm listening."
    ),
]

SENSITIVE_SIGNALS = [
    r"\babuse\b", r"\btrauma\b", r"\braped?\b", r"\bmolested\b",
    r"\bdomestic violence\b", r"\bassault\b", r"\bPTSD\b",
]

SENSITIVE_RESPONSES = [
    (
        "That sounds like something really painful to carry. "
        "You are safe here, and you don't have to share more than you're comfortable with.\n\n"
        "I want to support you. What would feel most helpful right now?"
    ),
    (
        "I'm really sorry you've experienced that. Your feelings make complete sense. "
        "Would it be okay if we talked about what kind of support might help you most?"
    ),
]


class TraumaSafeMode:
    def __init__(self):
        self._crisis_patterns = [re.compile(p, re.IGNORECASE) for p in CRISIS_SIGNALS]
        self._sensitive_patterns = [re.compile(p, re.IGNORECASE) for p in SENSITIVE_SIGNALS]
        print("[TraumaSafe] Loaded. Crisis detection active.")

    def is_crisis(self, text: str) -> bool:
        """Returns True if input contains crisis-level signals."""
        return any(p.search(text) for p in self._crisis_patterns)

    def is_sensitive(self, text: str) -> bool:
        """Returns True if input touches trauma/sensitive topics."""
        return any(p.search(text) for p in self._sensitive_patterns)

    def get_safe_response(self, text: str) -> str:
        """Return the appropriate safe response."""
        import random
        if self.is_crisis(text):
            return random.choice(SAFE_RESPONSES)
        if self.is_sensitive(text):
            return random.choice(SENSITIVE_RESPONSES)
        return "I'm here and I'm listening. Take your time."
