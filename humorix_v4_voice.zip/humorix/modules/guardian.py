"""
HUMORIX — Guardian System
Keeps Humorix running 24/7. Monitors crashes and auto-restarts.
Run this instead of main.py for production use.
"""

import subprocess
import sys
import time
import datetime
import os
from pathlib import Path

LOG_FILE = Path("data/logs/guardian.log")
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

MAX_RESTARTS = 10
RESTART_DELAY = 5  # seconds between restarts
CRASH_WINDOW = 60  # seconds — reset counter if stable for this long


class Guardian:
    def __init__(self):
        self.restart_count = 0
        self.last_start_time = None

    def log(self, message: str):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] {message}"
        print(line)
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")

    def run(self):
        self.log("Guardian started. Watching Humorix...")
        while True:
            self.last_start_time = time.time()
            self.log(f"Starting Humorix (attempt #{self.restart_count + 1})...")

            try:
                proc = subprocess.run(
                    [sys.executable, "main.py"],
                    cwd=Path(__file__).parent.parent
                )
                exit_code = proc.returncode
            except Exception as e:
                self.log(f"Launch error: {e}")
                exit_code = -1

            uptime = time.time() - self.last_start_time

            if uptime > CRASH_WINDOW:
                # Ran long enough — reset restart counter
                self.log(f"Process ran for {uptime:.0f}s. Resetting restart counter.")
                self.restart_count = 0
            else:
                self.restart_count += 1
                self.log(f"Process crashed after {uptime:.0f}s (exit code {exit_code}). Restart #{self.restart_count}.")

            if self.restart_count >= MAX_RESTARTS:
                self.log("⚠️  Too many rapid crashes. Guardian halting. Check logs.")
                break

            self.log(f"Restarting in {RESTART_DELAY}s...")
            time.sleep(RESTART_DELAY)


if __name__ == "__main__":
    Guardian().run()
