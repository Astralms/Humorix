"""
HUMORIX — Voice Handler
Real-time voice input using SpeechRecognition.
Install: pip install SpeechRecognition pyaudio
"""


class VoiceHandler:
    def __init__(self):
        self._available = False
        try:
            import speech_recognition as sr
            self.sr = sr
            self.recognizer = sr.Recognizer()
            self._available = True
            print("[VoiceHandler] SpeechRecognition loaded.")
        except ImportError:
            print("[VoiceHandler] SpeechRecognition not installed. Run: pip install SpeechRecognition pyaudio")

    def listen(self, timeout: int = 5) -> str:
        """
        Listen via microphone and return transcribed text.
        Returns empty string if unavailable or error.
        """
        if not self._available:
            return ""

        sr = self.sr
        with sr.Microphone() as source:
            print("[VoiceHandler] Listening...")
            self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
            try:
                audio = self.recognizer.listen(source, timeout=timeout)
                text = self.recognizer.recognize_google(audio)
                print(f"[VoiceHandler] Heard: {text}")
                return text
            except sr.WaitTimeoutError:
                print("[VoiceHandler] Timeout — no speech detected.")
                return ""
            except sr.UnknownValueError:
                print("[VoiceHandler] Could not understand audio.")
                return ""
            except sr.RequestError as e:
                print(f"[VoiceHandler] API error: {e}")
                return ""

    def text_to_speech(self, text: str):
        """
        Speak a response aloud.
        Install: pip install pyttsx3
        """
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty("rate", 165)
            engine.say(text)
            engine.runAndWait()
        except ImportError:
            print("[VoiceHandler] pyttsx3 not installed. Run: pip install pyttsx3")
        except Exception as e:
            print(f"[VoiceHandler] TTS error: {e}")
