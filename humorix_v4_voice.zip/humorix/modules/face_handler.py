"""
HUMORIX — Face Handler
Real-time facial emotion detection via webcam.
Install: pip install deepface opencv-python
"""


class FaceHandler:
    def __init__(self):
        self._available = False
        try:
            from deepface import DeepFace
            import cv2
            self.DeepFace = DeepFace
            self.cv2 = cv2
            self._available = True
            print("[FaceHandler] DeepFace loaded.")
        except ImportError:
            print("[FaceHandler] DeepFace not installed. Run: pip install deepface opencv-python")

    def detect(self) -> dict:
        """
        Capture one frame from webcam and detect emotion.
        Returns: { "emotion": str, "scores": dict }
        """
        if not self._available:
            return {"emotion": "unknown", "scores": {}}

        cv2 = self.cv2
        cap = cv2.VideoCapture(0)

        if not cap.isOpened():
            print("[FaceHandler] Cannot open webcam.")
            return {"emotion": "unknown", "scores": {}}

        ret, frame = cap.read()
        cap.release()

        if not ret:
            return {"emotion": "unknown", "scores": {}}

        try:
            result = self.DeepFace.analyze(frame, actions=["emotion"], enforce_detection=False)
            if isinstance(result, list):
                result = result[0]
            dominant = result.get("dominant_emotion", "neutral")
            scores = result.get("emotion", {})
            print(f"[FaceHandler] Detected: {dominant}")
            return {"emotion": dominant.lower(), "scores": scores}
        except Exception as e:
            print(f"[FaceHandler] Detection error: {e}")
            return {"emotion": "unknown", "scores": {}}

    def start_continuous(self, callback):
        """
        Run continuous face emotion detection.
        callback(emotion: str) is called each frame.
        Press 'q' to quit.
        """
        if not self._available:
            return

        cv2 = self.cv2
        cap = cv2.VideoCapture(0)

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            try:
                result = self.DeepFace.analyze(frame, actions=["emotion"], enforce_detection=False)
                if isinstance(result, list):
                    result = result[0]
                emotion = result.get("dominant_emotion", "neutral").lower()
                callback(emotion)
                cv2.putText(frame, f"Emotion: {emotion}", (30, 40),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 100), 2)
            except Exception:
                pass

            cv2.imshow("Humorix Face Detection", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        cap.release()
        cv2.destroyAllWindows()
