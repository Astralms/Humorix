"""
HUMORIX — Counselling Engine
CBT-inspired response generator.
Validates emotions, asks structured questions, suggests coping strategies.
"""

import random
from typing import Optional


# --- Response templates by emotion ---
VALIDATION_TEMPLATES = {
    "sadness": [
        "It sounds like you're going through a really tough time. That's completely valid.",
        "Feeling sad is a natural response to what you're experiencing. You're not alone.",
        "I hear you. It takes courage to acknowledge sadness.",
    ],
    "anger": [
        "It makes sense that you're feeling frustrated. Your feelings are valid.",
        "Anger often signals that something important to you has been affected.",
        "I understand — that situation sounds genuinely upsetting.",
    ],
    "anxiety": [
        "Anxiety can feel overwhelming. Let's take this one step at a time.",
        "It's understandable to feel anxious about this. You're not overreacting.",
        "I hear you. Worry is your mind trying to protect you — let's work through it.",
    ],
    "joy": [
        "That's wonderful! It's great to hear you're feeling positive.",
        "I love hearing that! Moments of joy are worth celebrating.",
    ],
    "guilt": [
        "Feeling guilty shows you care deeply. Let's explore what's behind that.",
        "It sounds like this is weighing on you. That's a sign of your empathy.",
    ],
    "loneliness": [
        "Loneliness can be incredibly painful. You reaching out matters.",
        "You're not as alone as it might feel right now. I'm here with you.",
    ],
    "neutral": [
        "Thanks for sharing that with me. I'm listening.",
        "I'm here. Tell me more about what's on your mind.",
    ],
}

CBT_QUESTIONS = {
    "sadness":    ["What do you think triggered this feeling?", "Is there something specific that happened recently?", "What would you tell a friend feeling this way?"],
    "anger":      ["What specifically made you feel this way?", "What would a calm resolution look like to you?", "Is there a need that isn't being met here?"],
    "anxiety":    ["What's the worst thing you imagine happening?", "How likely do you think that is, realistically?", "What's one small action you could take right now?"],
    "guilt":      ["What do you think you should have done differently?", "Have you been too hard on yourself about this?", "What would forgiveness look like here?"],
    "loneliness": ["When did you last feel connected with someone?", "Is there anyone you could reach out to today?", "What kind of connection are you craving most?"],
    "neutral":    ["What's been on your mind lately?", "Is there something specific you'd like to talk through?"],
}

COPING_STRATEGIES = {
    "sadness":    ["Try journaling your feelings for 5 minutes.", "Reach out to someone you trust today.", "Allow yourself to rest — recovery takes time."],
    "anger":      ["Take 10 deep breaths before responding.", "Write down what you're feeling without filtering.", "Go for a short walk to release physical tension."],
    "anxiety":    ["Try the 5-4-3-2-1 grounding technique.", "Break the worry into what you can and cannot control.", "Focus on one breath at a time."],
    "guilt":      ["Practice self-compassion: would you judge a friend this harshly?", "Consider what making amends might look like.", "Remind yourself that mistakes are part of being human."],
    "loneliness": ["Send a simple 'thinking of you' message to someone.", "Join an online community around a topic you enjoy.", "Schedule one social activity this week, even small."],
    "joy":        ["Savour this feeling — note what contributed to it.", "Share your happiness with someone close to you."],
    "neutral":    ["Take a moment to check in with yourself.", "Consider what would make today feel meaningful."],
}


class CounsellingEngine:
    def __init__(self):
        self.turn_count = 0
        print("[CounsellingEngine] Loaded (CBT mode).")

    def respond(self, user_input: str, emotion: str, history: list, context: dict) -> str:
        """Generate a structured, empathetic counselling response."""
        self.turn_count += 1
        parts = []

        # 1. Validate the emotion
        validation = self._get_validation(emotion)
        parts.append(validation)

        # 2. Ask a reflective question (every other turn)
        if self.turn_count % 2 == 1:
            question = self._get_question(emotion)
            parts.append(question)

        # 3. Suggest a coping strategy (every 3rd turn)
        if self.turn_count % 3 == 0:
            strategy = self._get_strategy(emotion)
            parts.append(f"💡 Something that might help: {strategy}")

        return " ".join(parts)

    def _get_validation(self, emotion: str) -> str:
        templates = VALIDATION_TEMPLATES.get(emotion, VALIDATION_TEMPLATES["neutral"])
        return random.choice(templates)

    def _get_question(self, emotion: str) -> str:
        questions = CBT_QUESTIONS.get(emotion, CBT_QUESTIONS["neutral"])
        return random.choice(questions)

    def _get_strategy(self, emotion: str) -> str:
        strategies = COPING_STRATEGIES.get(emotion, COPING_STRATEGIES["neutral"])
        return random.choice(strategies)
