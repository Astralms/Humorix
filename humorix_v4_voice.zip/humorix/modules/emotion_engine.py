"""
HUMORIX — Emotion Engine
Detects emotions from text input.
Uses keyword/rule-based detection by default.
Swap in a transformer model (e.g. HuggingFace) for production accuracy.
"""

import re
from typing import Optional


# --- Emotion keyword map (expand as needed) ---
EMOTION_KEYWORDS = {
    "joy":        ["happy", "excited", "great", "amazing", "love", "wonderful", "joyful", "elated", "fantastic", "glad"],
    "sadness":    ["sad", "unhappy", "depressed", "crying", "hopeless", "empty", "lonely", "grief", "heartbroken", "down"],
    "anger":      ["angry", "furious", "mad", "rage", "frustrated", "hate", "annoyed", "irritated", "livid", "pissed"],
    "anxiety":    ["anxious", "worried", "nervous", "scared", "panic", "stress", "overwhelmed", "afraid", "tense", "dread"],
    "disgust":    ["disgusting", "gross", "revolting", "sick", "horrible", "awful", "repulsed", "nasty"],
    "fear":       ["terrified", "frightened", "horror", "nightmare", "phobia", "dread", "petrified"],
    "surprise":   ["surprised", "shocked", "unexpected", "wow", "unbelievable", "astonished", "stunned"],
    "guilt":      ["guilty", "ashamed", "regret", "sorry", "blame", "fault", "embarrassed"],
    "loneliness": ["alone", "isolated", "lonely", "no one", "nobody", "abandoned", "left out"],
    "hopeful":    ["hope", "better", "improving", "looking forward", "optimistic", "bright side"],
    "neutral":    []
}


class EmotionEngine:
    def __init__(self):
        # Optional: load a real ML model here
        # from transformers import pipeline
        # self.model = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base")
        self.model = None
        print("[EmotionEngine] Loaded (keyword mode). Plug in ML model for higher accuracy.")

    def detect(self, text: str) -> dict:
        """
        Detect the dominant emotion in text.
        Returns: { "emotion": str, "confidence": float, "scores": dict }
        """
        if self.model:
            return self._ml_detect(text)
        return self._keyword_detect(text)

    def _keyword_detect(self, text: str) -> dict:
        text_lower = text.lower()
        scores = {}
        for emotion, keywords in EMOTION_KEYWORDS.items():
            if emotion == "neutral":
                continue
            count = sum(1 for kw in keywords if kw in text_lower)
            if count > 0:
                scores[emotion] = count

        if not scores:
            return {"emotion": "neutral", "confidence": 1.0, "scores": {}}

        top_emotion = max(scores, key=scores.get)
        total = sum(scores.values())
        confidence = round(scores[top_emotion] / total, 2)

        return {
            "emotion": top_emotion,
            "confidence": confidence,
            "scores": scores
        }

    def _ml_detect(self, text: str) -> dict:
        """Use HuggingFace transformer model (when loaded)."""
        try:
            results = self.model(text, top_k=None)
            top = results[0]
            return {
                "emotion": top["label"].lower(),
                "confidence": round(top["score"], 3),
                "scores": {r["label"].lower(): round(r["score"], 3) for r in results}
            }
        except Exception as e:
            print(f"[EmotionEngine] ML model error: {e}")
            return self._keyword_detect(text)

    def get_emotional_label(self, emotion: str) -> str:
        """Return a human-friendly description of the emotion."""
        labels = {
            "joy": "feeling happy and positive",
            "sadness": "feeling sad or down",
            "anger": "feeling angry or frustrated",
            "anxiety": "feeling anxious or worried",
            "disgust": "feeling disgusted or repelled",
            "fear": "feeling fearful",
            "surprise": "feeling surprised",
            "guilt": "feeling guilty or ashamed",
            "loneliness": "feeling lonely or isolated",
            "hopeful": "feeling hopeful",
            "neutral": "in a neutral state",
        }
        return labels.get(emotion, "experiencing something")
